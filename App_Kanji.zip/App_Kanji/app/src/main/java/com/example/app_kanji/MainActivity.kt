package com.example.app_kanji

import com.example.app_kanji.databinding.ActivityMainBinding
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telephony.emergency.EmergencyNumber
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    //Nav Bottom
    private lateinit var binding : ActivityMainBinding

    //Nav Lateral
    private lateinit var drawerLayout: DrawerLayout

    //Nav Lateral
    override fun onNavigationItemSelected(item: MenuItem): Boolean {

        replaceFragment(Home())
        binding.bottomNavigationView.setOnItemSelectedListener {
            when(it.itemId){
                R.id.home -> replaceFragment(Home())
                R.id.foto -> replaceFragment(Foto())
                R.id.treinar -> replaceFragment(Treinar())
                R.id.pesquisar -> replaceFragment(Pesquisar())
                else -> { }
            }

            true
        }
        when (item.itemId) {
            R.id.nav_configuracoes -> supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, Configuracoes()).commit()
            R.id.nav_email -> supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, Email()).commit()
            R.id.nav_info -> supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, Info()).commit()
            R.id.nav_login -> Toast.makeText(this, "Login!!!", Toast.LENGTH_SHORT).show()
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Nav Lateral
        drawerLayout = findViewById(R.id.drawer_layout)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        val navigationView = findViewById<NavigationView>(R.id.nav_view)
        navigationView.setNavigationItemSelectedListener(this)
        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()




        //Nav bottom


        /*binding.bottomNavigationView.setOnItemSelectedListener { menuItem ->
            if (menuItem.itemId == R.id.home) {
                replaceFragment(Home())
            } else if (menuItem.itemId == R.id.foto) {
                replaceFragment(Foto())
            } else if (menuItem.itemId == R.id.pesquisar) {
                replaceFragment(Treinar())
            }
            // You can add more else-if blocks if needed for additional menu items

            true // Return true to indicate that the item has been selected
        }*/
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)


        } else {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun replaceFragment(fragment : Fragment){
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.frame_layout, fragment)
        fragmentTransaction.commit()
    }
}


